$(document).ready(function(){
	
	$('.menu-res').click(function(){
		$('.menu').slideToggle();
		return false
	});
	
});